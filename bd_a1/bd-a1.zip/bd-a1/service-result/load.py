import pandas as pd

def load_dataset(path):
    return pd.read_csv(path)
